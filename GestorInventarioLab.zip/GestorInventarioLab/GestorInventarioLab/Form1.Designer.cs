﻿namespace GestorInventarioLab
{
    partial class FrmPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private Button btnRegistrarEquipo;
        private Button btnRegistrarEstudiante;
        private Button btnPrestar;
        private Button btnDevolver;
        private Button btnConsultar;
        private Button btnSalir;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnRegistrarEquipo = new Button();
            btnRegistrarEstudiante = new Button();
            btnPrestar = new Button();
            btnDevolver = new Button();
            btnConsultar = new Button();
            btnSalir = new Button();
            SuspendLayout();
            // 
            // btnRegistrarEquipo
            // 
            btnRegistrarEquipo.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            btnRegistrarEquipo.Location = new Point(50, 40);
            btnRegistrarEquipo.Name = "btnRegistrarEquipo";
            btnRegistrarEquipo.Size = new Size(250, 50);
            btnRegistrarEquipo.Text = "Registrar Equipo";
            btnRegistrarEquipo.UseVisualStyleBackColor = true;
            btnRegistrarEquipo.Click += btnRegistrarEquipo_Click;
            // 
            // btnRegistrarEstudiante
            // 
            btnRegistrarEstudiante.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            btnRegistrarEstudiante.Location = new Point(50, 100);
            btnRegistrarEstudiante.Name = "btnRegistrarEstudiante";
            btnRegistrarEstudiante.Size = new Size(250, 50);
            btnRegistrarEstudiante.Text = "Registrar Estudiante";
            btnRegistrarEstudiante.UseVisualStyleBackColor = true;
            btnRegistrarEstudiante.Click += btnRegistrarEstudiante_Click;
            // 
            // btnPrestar
            // 
            btnPrestar.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            btnPrestar.Location = new Point(50, 160);
            btnPrestar.Name = "btnPrestar";
            btnPrestar.Size = new Size(250, 50);
            btnPrestar.Text = "Prestar Equipo";
            btnPrestar.UseVisualStyleBackColor = true;
            btnPrestar.Click += btnPrestar_Click;
            // 
            // btnDevolver
            // 
            btnDevolver.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            btnDevolver.Location = new Point(50, 220);
            btnDevolver.Name = "btnDevolver";
            btnDevolver.Size = new Size(250, 50);
            btnDevolver.Text = "Devolver Equipo";
            btnDevolver.UseVisualStyleBackColor = true;
            btnDevolver.Click += btnDevolver_Click;
            // 
            // btnConsultar
            // 
            btnConsultar.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            btnConsultar.Location = new Point(50, 280);
            btnConsultar.Name = "btnConsultar";
            btnConsultar.Size = new Size(250, 50);
            btnConsultar.Text = "Consultar Estado";
            btnConsultar.UseVisualStyleBackColor = true;
            btnConsultar.Click += btnConsultar_Click;
            // 
            // btnSalir
            // 
            btnSalir.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            btnSalir.Location = new Point(50, 340);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(250, 50);
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // FrmPrincipal
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnRegistrarEquipo);
            Controls.Add(btnRegistrarEstudiante);
            Controls.Add(btnPrestar);
            Controls.Add(btnDevolver);
            Controls.Add(btnConsultar);
            Controls.Add(btnSalir);
            Name = "FrmPrincipal";
            Text = "Gestor de Inventario - Laboratorio";
            Load += FrmPrincipal_Load;
            ResumeLayout(false);
        }

        #endregion
    }
}
