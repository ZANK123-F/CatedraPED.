namespace GestorInventarioLab
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void btnRegistrarEquipo_Click(object sender, EventArgs e)
        {
            FrmRegistrarEquipo frm = new FrmRegistrarEquipo();
            frm.ShowDialog(); 
        }

        private void btnRegistrarEstudiante_Click(object sender, EventArgs e)
        {
            FrmRegistrarEstudiante frm = new FrmRegistrarEstudiante();
            frm.ShowDialog(); // o .Show() si prefer�s que no sea modal
        }


        private void btnPrestar_Click(object sender, EventArgs e)
        {
            FrmPrestarEquipo frm = new FrmPrestarEquipo();
            frm.ShowDialog();
        }


        private void btnDevolver_Click(object sender, EventArgs e)
        {
            FrmDevolverEquipo frm = new FrmDevolverEquipo();
            frm.ShowDialog();
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            FrmConsultarEstado frm = new FrmConsultarEstado();
            frm.ShowDialog();
        }


        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
