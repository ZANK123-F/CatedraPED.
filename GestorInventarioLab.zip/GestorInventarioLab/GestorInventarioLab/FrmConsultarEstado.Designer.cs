﻿namespace GestorInventarioLab
{
    partial class FrmConsultarEstado
    {
        private System.ComponentModel.IContainer components = null;

        private Label lblCodigo;
        private TextBox txtCodigo;
        private Button btnBuscar;
        private TextBox txtResultado;
        private Button btnCerrar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblCodigo = new Label();
            txtCodigo = new TextBox();
            btnBuscar = new Button();
            txtResultado = new TextBox();
            btnCerrar = new Button();
            SuspendLayout();
            // 
            // lblCodigo
            // 
            lblCodigo.AutoSize = true;
            lblCodigo.Location = new Point(30, 30);
            lblCodigo.Name = "lblCodigo";
            lblCodigo.Size = new Size(165, 25);
            lblCodigo.TabIndex = 0;
            lblCodigo.Text = "Código del equipo:";
            // 
            // txtCodigo
            // 
            txtCodigo.Location = new Point(170, 30);
            txtCodigo.Name = "txtCodigo";
            txtCodigo.Size = new Size(200, 31);
            txtCodigo.TabIndex = 1;
            // 
            // btnBuscar
            // 
            btnBuscar.Location = new Point(390, 30);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(100, 30);
            btnBuscar.TabIndex = 2;
            btnBuscar.Text = "Buscar";
            btnBuscar.Click += btnBuscar_Click;
            // 
            // txtResultado
            // 
            txtResultado.Location = new Point(30, 80);
            txtResultado.Multiline = true;
            txtResultado.Name = "txtResultado";
            txtResultado.ReadOnly = true;
            txtResultado.ScrollBars = ScrollBars.Vertical;
            txtResultado.Size = new Size(460, 150);
            txtResultado.TabIndex = 3;
            // 
            // btnCerrar
            // 
            btnCerrar.Location = new Point(200, 250);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(120, 40);
            btnCerrar.TabIndex = 4;
            btnCerrar.Text = "Cerrar";
            btnCerrar.Click += btnCerrar_Click;
            // 
            // FrmConsultarEstado
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(520, 310);
            Controls.Add(lblCodigo);
            Controls.Add(txtCodigo);
            Controls.Add(btnBuscar);
            Controls.Add(txtResultado);
            Controls.Add(btnCerrar);
            Name = "FrmConsultarEstado";
            Text = "Consultar Estado del Equipo";
            Load += FrmConsultarEstado_Load;
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
