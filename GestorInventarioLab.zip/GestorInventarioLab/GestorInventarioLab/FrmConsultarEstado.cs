﻿namespace GestorInventarioLab
{
    public partial class FrmConsultarEstado : Form
    {
        public FrmConsultarEstado()
        {
            InitializeComponent();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {

            string codigo = txtCodigo.Text.Trim().ToUpper();

            if (codigo == "EQ001")
            {
                txtResultado.Text = "Código: EQ001\nNombre: Multímetro\nTipo: Medición\nEstado: Disponible";
            }
            else if (codigo == "EQ002")
            {
                txtResultado.Text = "Código: EQ002\nNombre: Osciloscopio\nTipo: Visualización\nEstado: Prestado";
            }
            else
            {
                txtResultado.Text = "Equipo no encontrado.";
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmConsultarEstado_Load(object sender, EventArgs e)
        {

        }
    }
}
