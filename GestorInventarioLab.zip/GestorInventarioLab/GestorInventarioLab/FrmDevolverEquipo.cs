﻿namespace GestorInventarioLab
{
    public partial class FrmDevolverEquipo : Form
    {
        public FrmDevolverEquipo()
        {
            InitializeComponent();
        }

        private void btnDevolver_Click(object sender, EventArgs e)
        {
            string mensaje = $"Devolución registrada:\n" +
                             $"- Equipo: {txtCodigoEquipo.Text}\n" +
                             $"- Estudiante: {txtCarnetEstudiante.Text}\n" +
                             $"- Hora: {dtpHora.Value.ToShortTimeString()}";
            MessageBox.Show(mensaje, "Devolución Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
