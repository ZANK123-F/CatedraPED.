﻿namespace GestorInventarioLab
{
    partial class FrmPrestarEquipo
    {
        private System.ComponentModel.IContainer components = null;

        private Label lblCodigoEquipo;
        private Label lblCarnetEstudiante;
        private Label lblHora;
        private TextBox txtCodigoEquipo;
        private TextBox txtCarnetEstudiante;
        private DateTimePicker dtpHora;
        private Button btnRegistrar;
        private Button btnCancelar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblCodigoEquipo = new Label();
            lblCarnetEstudiante = new Label();
            lblHora = new Label();
            txtCodigoEquipo = new TextBox();
            txtCarnetEstudiante = new TextBox();
            dtpHora = new DateTimePicker();
            btnRegistrar = new Button();
            btnCancelar = new Button();
            SuspendLayout();
            // 
            // lblCodigoEquipo
            // 
            lblCodigoEquipo.AutoSize = true;
            lblCodigoEquipo.Location = new Point(30, 30);
            lblCodigoEquipo.Text = "Código del equipo:";
            // 
            // txtCodigoEquipo
            // 
            txtCodigoEquipo.Location = new Point(180, 30);
            txtCodigoEquipo.Size = new Size(200, 30);
            // 
            // lblCarnetEstudiante
            // 
            lblCarnetEstudiante.AutoSize = true;
            lblCarnetEstudiante.Location = new Point(30, 70);
            lblCarnetEstudiante.Text = "Carnet del estudiante:";
            // 
            // txtCarnetEstudiante
            // 
            txtCarnetEstudiante.Location = new Point(180, 70);
            txtCarnetEstudiante.Size = new Size(200, 30);
            // 
            // lblHora
            // 
            lblHora.AutoSize = true;
            lblHora.Location = new Point(30, 110);
            lblHora.Text = "Hora de préstamo:";
            // 
            // dtpHora
            // 
            dtpHora.Location = new Point(180, 110);
            dtpHora.Format = DateTimePickerFormat.Time;
            dtpHora.ShowUpDown = true;
            dtpHora.Value = DateTime.Now;
            dtpHora.Size = new Size(200, 30);
            // 
            // btnRegistrar
            // 
            btnRegistrar.Location = new Point(70, 180);
            btnRegistrar.Size = new Size(120, 40);
            btnRegistrar.Text = "Registrar";
            btnRegistrar.Click += btnRegistrar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(210, 180);
            btnCancelar.Size = new Size(120, 40);
            btnCancelar.Text = "Cancelar";
            btnCancelar.Click += btnCancelar_Click;
            // 
            // FrmPrestarEquipo
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(450, 260);
            Controls.Add(lblCodigoEquipo);
            Controls.Add(txtCodigoEquipo);
            Controls.Add(lblCarnetEstudiante);
            Controls.Add(txtCarnetEstudiante);
            Controls.Add(lblHora);
            Controls.Add(dtpHora);
            Controls.Add(btnRegistrar);
            Controls.Add(btnCancelar);
            Name = "FrmPrestarEquipo";
            Text = "Préstamo de Equipo";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
