﻿namespace GestorInventarioLab
{
    public partial class FrmPrestarEquipo : Form
    {
        public FrmPrestarEquipo()
        {
            InitializeComponent();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            string mensaje = $"Préstamo registrado:\n" +
                             $"- Equipo: {txtCodigoEquipo.Text}\n" +
                             $"- Estudiante: {txtCarnetEstudiante.Text}\n" +
                             $"- Hora: {dtpHora.Value.ToShortTimeString()}";
            MessageBox.Show(mensaje, "Préstamo Exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
