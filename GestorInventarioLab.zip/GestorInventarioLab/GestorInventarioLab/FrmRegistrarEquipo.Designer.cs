﻿namespace GestorInventarioLab
{
    partial class FrmRegistrarEquipo
    {
        private System.ComponentModel.IContainer components = null;

        private Label lblCodigo;
        private Label lblNombre;
        private Label lblTipo;
        private Label lblEstado;
        private TextBox txtCodigo;
        private TextBox txtNombre;
        private TextBox txtTipo;
        private ComboBox cmbEstado;
        private Button btnGuardar;
        private Button btnCancelar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblCodigo = new Label();
            lblNombre = new Label();
            lblTipo = new Label();
            lblEstado = new Label();
            txtCodigo = new TextBox();
            txtNombre = new TextBox();
            txtTipo = new TextBox();
            cmbEstado = new ComboBox();
            btnGuardar = new Button();
            btnCancelar = new Button();
            SuspendLayout();
            // 
            // lblCodigo
            // 
            lblCodigo.AutoSize = true;
            lblCodigo.Location = new Point(30, 30);
            lblCodigo.Text = "Código:";
            // 
            // txtCodigo
            // 
            txtCodigo.Location = new Point(150, 30);
            txtCodigo.Size = new Size(200, 30);
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(30, 70);
            lblNombre.Text = "Nombre:";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(150, 70);
            txtNombre.Size = new Size(200, 30);
            // 
            // lblTipo
            // 
            lblTipo.AutoSize = true;
            lblTipo.Location = new Point(30, 110);
            lblTipo.Text = "Tipo:";
            // 
            // txtTipo
            // 
            txtTipo.Location = new Point(150, 110);
            txtTipo.Size = new Size(200, 30);
            // 
            // lblEstado
            // 
            lblEstado.AutoSize = true;
            lblEstado.Location = new Point(30, 150);
            lblEstado.Text = "Estado:";
            // 
            // cmbEstado
            // 
            cmbEstado.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEstado.Items.AddRange(new object[] { "Disponible", "Prestado", "En reparación" });
            cmbEstado.Location = new Point(150, 150);
            cmbEstado.Size = new Size(200, 30);
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(70, 210);
            btnGuardar.Size = new Size(120, 40);
            btnGuardar.Text = "Guardar";
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(210, 210);
            btnCancelar.Size = new Size(120, 40);
            btnCancelar.Text = "Cancelar";
            btnCancelar.Click += btnCancelar_Click;
            // 
            // FrmRegistrarEquipo
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(400, 300);
            Controls.Add(lblCodigo);
            Controls.Add(txtCodigo);
            Controls.Add(lblNombre);
            Controls.Add(txtNombre);
            Controls.Add(lblTipo);
            Controls.Add(txtTipo);
            Controls.Add(lblEstado);
            Controls.Add(cmbEstado);
            Controls.Add(btnGuardar);
            Controls.Add(btnCancelar);
            Name = "FrmRegistrarEquipo";
            Text = "Registrar Equipo";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
