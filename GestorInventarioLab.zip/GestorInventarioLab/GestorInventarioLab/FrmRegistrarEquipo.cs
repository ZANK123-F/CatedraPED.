﻿namespace GestorInventarioLab
{
    public partial class FrmRegistrarEquipo : Form
    {
        public FrmRegistrarEquipo()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string mensaje = $"Equipo registrado:\n" +
                             $"- Código: {txtCodigo.Text}\n" +
                             $"- Nombre: {txtNombre.Text}\n" +
                             $"- Tipo: {txtTipo.Text}\n" +
                             $"- Estado: {cmbEstado.SelectedItem}";
            MessageBox.Show(mensaje, "Registro Exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close(); // Opcional: cerrar al guardar
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmRegistrarEquipo_Load(object sender, EventArgs e)
        {

        }
    }
}
