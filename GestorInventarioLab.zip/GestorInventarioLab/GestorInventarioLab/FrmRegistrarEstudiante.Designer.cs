﻿namespace GestorInventarioLab
{
    partial class FrmRegistrarEstudiante
    {
        private System.ComponentModel.IContainer components = null;

        private Label lblCarnet;
        private Label lblNombre;
        private Label lblCarrera;
        private Label lblGrupo;
        private TextBox txtCarnet;
        private TextBox txtNombre;
        private TextBox txtCarrera;
        private TextBox txtGrupo;
        private Button btnGuardar;
        private Button btnCancelar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblCarnet = new Label();
            lblNombre = new Label();
            lblCarrera = new Label();
            lblGrupo = new Label();
            txtCarnet = new TextBox();
            txtNombre = new TextBox();
            txtCarrera = new TextBox();
            txtGrupo = new TextBox();
            btnGuardar = new Button();
            btnCancelar = new Button();
            SuspendLayout();
            // 
            // lblCarnet
            // 
            lblCarnet.AutoSize = true;
            lblCarnet.Location = new Point(30, 30);
            lblCarnet.Text = "Carnet:";
            // 
            // txtCarnet
            // 
            txtCarnet.Location = new Point(150, 30);
            txtCarnet.Size = new Size(200, 30);
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(30, 70);
            lblNombre.Text = "Nombre:";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(150, 70);
            txtNombre.Size = new Size(200, 30);
            // 
            // lblCarrera
            // 
            lblCarrera.AutoSize = true;
            lblCarrera.Location = new Point(30, 110);
            lblCarrera.Text = "Carrera:";
            // 
            // txtCarrera
            // 
            txtCarrera.Location = new Point(150, 110);
            txtCarrera.Size = new Size(200, 30);
            // 
            // lblGrupo
            // 
            lblGrupo.AutoSize = true;
            lblGrupo.Location = new Point(30, 150);
            lblGrupo.Text = "Grupo:";
            // 
            // txtGrupo
            // 
            txtGrupo.Location = new Point(150, 150);
            txtGrupo.Size = new Size(200, 30);
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(70, 210);
            btnGuardar.Size = new Size(120, 40);
            btnGuardar.Text = "Guardar";
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(210, 210);
            btnCancelar.Size = new Size(120, 40);
            btnCancelar.Text = "Cancelar";
            btnCancelar.Click += btnCancelar_Click;
            // 
            // FrmRegistrarEstudiante
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(400, 300);
            Controls.Add(lblCarnet);
            Controls.Add(txtCarnet);
            Controls.Add(lblNombre);
            Controls.Add(txtNombre);
            Controls.Add(lblCarrera);
            Controls.Add(txtCarrera);
            Controls.Add(lblGrupo);
            Controls.Add(txtGrupo);
            Controls.Add(btnGuardar);
            Controls.Add(btnCancelar);
            Name = "FrmRegistrarEstudiante";
            Text = "Registrar Estudiante";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
