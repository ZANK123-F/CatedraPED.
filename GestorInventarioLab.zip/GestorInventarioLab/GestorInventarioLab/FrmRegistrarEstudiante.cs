﻿namespace GestorInventarioLab
{
    public partial class FrmRegistrarEstudiante : Form
    {
        public FrmRegistrarEstudiante()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string mensaje = $"Estudiante registrado:\n" +
                             $"- Carnet: {txtCarnet.Text}\n" +
                             $"- Nombre: {txtNombre.Text}\n" +
                             $"- Carrera: {txtCarrera.Text}\n" +
                             $"- Grupo: {txtGrupo.Text}";
            MessageBox.Show(mensaje, "Registro Exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
