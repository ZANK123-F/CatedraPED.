﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestorInventarioLab
{
    public class Equipo
    {
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Tipo { get; set; }
        public string Estado { get; set; } // Disponible, Prestado, En reparación
    }

    public class Estudiante
    {
        public string Carnet { get; set; }
        public string Nombre { get; set; }
        public string Carrera { get; set; }
        public string Grupo { get; set; }
    }

    public class Prestamo
    {
        public string CodigoEquipo { get; set; }
        public string CarnetEstudiante { get; set; }
        public DateTime HoraInicio { get; set; }
        public DateTime? HoraFin { get; set; }
    }
}
